1. Install All Font in this folder

2. run .reg file

	or

1. run Install-FontsConsole.ps1
